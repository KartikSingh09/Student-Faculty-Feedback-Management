<html>
<head>
    <title>Admin Login - Feedback Management System</title>
    <link rel="stylesheet" type="text/css" href="style/logincss.css">
    <style>
    </style>
</head>
<body>
<div id="ab1" >
    <center><h1 style="font-size: 58px; font-style:arial;">FEEDBACK MANAGEMENT SYSTEM</h1></center>
    <p id="p1"><em>"An easier way to Manage and Give Feedbacks....!!"</em></p>
    </div>
    <ul class="active">
       <li> <a href="index.html">Home</a> </li>
       
    </ul>
</div>
<div style="text-align:center; margin-top:100px;">
<a href="add_faculty.php"><button class="btn">Add New Faculty</button></a>&nbsp;&nbsp;&nbsp;
 <a href="view_faculty.php"><button class="btn">Faculty Details</button></a>
<br><br>
 <a href="student_details.php"><button class="btn">Add New Student</button></a>&nbsp;&nbsp;&nbsp;
 <a href="view_student.php"><button class="btn">Student Details</button></a>
 <br><br>
 <a href="Feedbacks.php"><button class="btn">Feedbacks</button></a>
</div>
</body>
</html>
