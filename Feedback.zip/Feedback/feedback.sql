-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2024 at 01:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `feedback`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`) VALUES
(1, 'kartik', 'abc@1234');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_info`
--

CREATE TABLE `faculty_info` (
  `faculty_id` int(10) NOT NULL,
  `faculty_name` varchar(50) NOT NULL,
  `faculty_subject` varchar(50) NOT NULL,
  `faculty_email` varchar(50) NOT NULL,
  `faculty_gender` enum('male','female') NOT NULL,
  `assign_division` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_info`
--

INSERT INTO `faculty_info` (`faculty_id`, `faculty_name`, `faculty_subject`, `faculty_email`, `faculty_gender`, `assign_division`) VALUES
(1122, 'Raghav Singh', 'Statistics', 'rahgav@gmail.com', 'male', 'A,B,C,D'),
(1123, 'Sonali Pathak', 'Statistics', 'sonali@gmail.com', 'female', 'E,F,G,H'),
(1124, 'Farukh Abdula', 'Project - 2', 'farukh@gmail.com', 'male', 'A,B,C,D,E,F,G,H'),
(1126, 'Krishna Patel', 'EMA', 'krishna@gmail.com', 'male', 'A,B,C,D,E,F,G,H'),
(1128, 'Priyavate Driveti', 'JAVA', 'priyavate@gamil.com', 'male', 'A,B,C,D,E'),
(1129, 'Manish Joshi', 'JAVA', 'manish@gmail.com', 'male', 'F,G,H'),
(1130, 'Komal Gupta', 'Maths', 'komal@gmail.com', 'female', 'A,B,C,D'),
(1131, 'Shika Bansal', 'FOW', 'shikha@gmail.com', 'female', 'A,B,C,D');

-- --------------------------------------------------------

--
-- Table structure for table `feed`
--

CREATE TABLE `feed` (
  `id` int(11) NOT NULL,
  `faculty_id` int(10) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `que1` int(10) NOT NULL,
  `que2` int(10) NOT NULL,
  `que3` int(11) NOT NULL,
  `que4` int(11) NOT NULL,
  `que5` int(11) NOT NULL,
  `que6` int(11) NOT NULL,
  `que7` int(11) NOT NULL,
  `que8` int(11) NOT NULL,
  `que9` int(11) NOT NULL,
  `que10` int(11) NOT NULL,
  `comment` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feed`
--

INSERT INTO `feed` (`id`, `faculty_id`, `student_id`, `que1`, `que2`, `que3`, `que4`, `que5`, `que6`, `que7`, `que8`, `que9`, `que10`, `comment`) VALUES
(25, 1123, '2205103110004', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 'wed'),
(26, 1130, '1', 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 'Excellent Teaching Skills....!');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `sem` int(10) NOT NULL,
  `sub1` varchar(50) DEFAULT NULL,
  `sub2` varchar(50) DEFAULT NULL,
  `sub3` varchar(50) DEFAULT NULL,
  `sub4` varchar(50) DEFAULT NULL,
  `sub5` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`sem`, `sub1`, `sub2`, `sub3`, `sub4`, `sub5`) VALUES
(1, 'Maths', 'FOW', 'FOP', 'FOC', 'Financial Accounting'),
(2, 'Project', 'CS - 2', 'Python', 'BSE', 'PHP'),
(3, 'JAVA', 'EMA', 'Data Structures', 'ASP.net', 'DCN'),
(4, 'Project - 2', 'MAD', 'Statistics', 'BIS', 'CSF');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `student_id` varchar(100) NOT NULL,
  `student_name` varchar(40) NOT NULL,
  `student_email` varchar(50) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `division` varchar(5) NOT NULL,
  `sem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`student_id`, `student_name`, `student_email`, `gender`, `division`, `sem`) VALUES
('1', 'Bharti', 'bharti@gmail.com', 'Female', 'A', 1),
('2', 'anil yadav', 'anil@gmail.com', 'Male', 'A', 1),
('2205103110004', 'Diya Mehta', 'diyaMehta@gmail.com', 'Female', 'H', 4),
('2205103120009', 'Pratibha Agarwal', 'pratibha@gmail.com', 'Female', 'H', 4),
('2205103140014', 'Kartik Singh', 'kartik7802057469@gmail.com', 'Male', 'H', 4),
('3', 'Shyam', 'shyam@gmail.com', 'Male', 'A', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_info`
--
ALTER TABLE `faculty_info`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `feed`
--
ALTER TABLE `feed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`sem`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feed`
--
ALTER TABLE `feed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
